let hours = document.getElementById('hrs');
let minutes = document.getElementById('min');
let seconds = document.getElementById('sec');

setInterval(()=>
{
    let date = new Date();
    let hrs = date.getHours()*30;
    let min = date.getMinutes()*6;
    let sec = date.getSeconds()*6;
    hrs.style.transform=`rotateZ(${(hrs) + (min/12)}deg)`;
    min.style.transform=`rotateZ${min}deg`;
    sec.style.transform=`rotateZ${sec}deg`;
    
console.log(min);
})

